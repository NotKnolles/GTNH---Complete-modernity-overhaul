# AE2-Dark-Mode
This pack includes dark mode blocks for Ae2 and additions. Based on AE2 Dark Mode created by Ridanisaurus. Made specially for [GTNH](https://www.gtnewhorizons.com/).

### The pack only inludes darker blocks, not gui!

<img width="2177" height="1377" alt="PicDarkMode" src="https://github.com/user-attachments/assets/1c957114-8559-4550-8f5e-01f03a29c9f5" />

### Contribution:
AE2 Dark Mode by Ridanisaurus:
> [CurseForge](https://www.curseforge.com/minecraft/texture-packs/ae2-dark-mode)
>
> [Modrinth](https://modrinth.com/resourcepack/ae2-dark-mode)

### Licensing

[![](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-yellow.svg?style=flat-square)](https://creativecommons.org/licenses/by-nc-sa/4.0/)
