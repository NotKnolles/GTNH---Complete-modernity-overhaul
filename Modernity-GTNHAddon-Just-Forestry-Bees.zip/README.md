# Just-Forestry-Bees-
ResourcePack designed to bring back old forestry bees
meant to be used above any resourcepack that changes bees

Made by: DarkScorpyon
(all assets from Forestry 1.7.10 mod)

Also check Modernity project here:
https://github.com/ABKQPO/Modernity-GTNH


![pack](https://github.com/user-attachments/assets/005ad8d1-213e-43a8-9e86-e3b4fbb785d5)
