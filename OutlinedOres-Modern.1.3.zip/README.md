# OutlinedOres-Modern

Adds a solid border that matches the color of the ore.

Outlined Ores for GregTech New Horizon modern textures. Compatible with [Modernity-GNTH](https://github.com/ABKQPO/Modernity-GTNH).

### Little Preview
![OutlinedOres-NoOutline](https://github.com/user-attachments/assets/f95007d4-f48e-4669-a3c7-295f29948532)
![OutlinedOres-Outline](https://github.com/user-attachments/assets/b8429662-17da-49b6-97b8-fac1b3b34d0b)

> [Other resource packs](https://wiki.gtnewhorizons.com/wiki/Resource_Packs)

Special thanks to schneid3306 for starting the Outline Ores pack!
