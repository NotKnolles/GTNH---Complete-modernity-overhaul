# Just-Productive-Bees-
This Repository aims to bring Productive Bees-inspired bees to 1.7.10

Animations Recorded by: ABKQPO
Outline and Crown crop by: DarkScorpyon

Design made by both :) inspired on ProductiveBees

you can find the full modernity project here:
https://github.com/ABKQPO/Modernity-GTNH


![pack](https://github.com/user-attachments/assets/cec38891-145d-48d0-9fc7-96cc1ad7d8ac)
